// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IImageDto } from '../../../../models/generatedtypes';
import { ImageRepository } from '../../../../services/generated/image-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class ImageCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new ImageRepository(http, configurations, injector);
  }

  data: IImageDto[] = [];
  dataSource: ImageRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    otherIdentifier: new FormControl(''),
    name: new FormControl(''),
    largeThumbUrl: new FormControl(''),
    smallThumbUrl: new FormControl(''),
    description: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    otherIdentifier: '',
    name: '',
    largeThumbUrl: '',
    smallThumbUrl: '',
    description: '',
    });
  }

  populateForm(image) {
     this.form.setValue(image);
  }

  getImages() {

  }

  insertImage(image) {

  }

  updateImage(image) {

  }

  deleteImage(id: number) {

  }
}



