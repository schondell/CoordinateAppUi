// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { ImageDto } from 'src/app/models/generatedtypes';
import { ImageCacheService } from './CacheService/image-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { ImageTypeRepository } from 'src/app/services/generated/imagetype-repository';
import { ImageStatusRepository } from 'src/app/services/generated/imagestatus-repository';

@Component({
  selector: 'app-image-form',
  templateUrl: './image-form.component.html',
  styleUrls: ['./image-form.component.css'],
  animations: [fadeInOut]
})
export class ImageFormComponent implements OnInit {


// column ImageTypeId
	imageTypeIds: IDropDownItem[] =  new Array();

// column ImageStatusId
	imageStatusIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getImages();
		this.imageTypeIdRepository.getImageTypesDropDownItems().subscribe(data => this.imageTypeIds = data);
		this.imageStatusIdRepository.getImageStatussDropDownItems().subscribe(data => this.imageStatusIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: ImageCacheService,
    private alertService: AlertService,
		private imageTypeIdRepository: ImageTypeRepository,
		private imageStatusIdRepository: ImageStatusRepository,
    public dialogRef: MatDialogRef<ImageFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new ImageDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertImage(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
