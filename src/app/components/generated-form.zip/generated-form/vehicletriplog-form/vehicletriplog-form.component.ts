// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { VehicleTripLogDto } from 'src/app/models/generatedtypes';
import { VehicleTripLogCacheService } from './CacheService/vehicletriplog-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { VehicleTripLogRepository } from 'src/app/services/generated/vehicletriplog-repository';
import { VehicleRepository } from 'src/app/services/generated/vehicle-repository';
import { UserRepository } from 'src/app/services/generated/user-repository';
import { WorkItemRepository } from 'src/app/services/generated/workitem-repository';
import { VehicleTripTypeRepository } from 'src/app/services/generated/vehicletriptype-repository';

@Component({
  selector: 'app-vehicletriplog-form',
  templateUrl: './vehicletriplog-form.component.html',
  styleUrls: ['./vehicletriplog-form.component.css'],
  animations: [fadeInOut]
})
export class VehicleTripLogFormComponent implements OnInit {


// column VehicleTripLogId
	vehicleTripLogIds: IDropDownItem[] =  new Array();

// column VehicleId
	vehicleIds: IDropDownItem[] =  new Array();

// column UserId
	userIds: IDropDownItem[] =  new Array();

// column WorkItemId
	workItemIds: IDropDownItem[] =  new Array();

// column VehicleTripTypeId
	vehicleTripTypeIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getVehicleTripLogs();
		this.vehicleTripLogIdRepository.getVehicleTripLogsDropDownItems().subscribe(data => this.vehicleTripLogIds = data);
		this.vehicleIdRepository.getVehiclesDropDownItems().subscribe(data => this.vehicleIds = data);
		this.userIdRepository.getUsersDropDownItems().subscribe(data => this.userIds = data);
		this.workItemIdRepository.getWorkItemsDropDownItems().subscribe(data => this.workItemIds = data);
		this.vehicleTripTypeIdRepository.getVehicleTripTypesDropDownItems().subscribe(data => this.vehicleTripTypeIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: VehicleTripLogCacheService,
    private alertService: AlertService,
		private vehicleTripLogIdRepository: VehicleTripLogRepository,
		private vehicleIdRepository: VehicleRepository,
		private userIdRepository: UserRepository,
		private workItemIdRepository: WorkItemRepository,
		private vehicleTripTypeIdRepository: VehicleTripTypeRepository,
    public dialogRef: MatDialogRef<VehicleTripLogFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new VehicleTripLogDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertVehicleTripLog(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
