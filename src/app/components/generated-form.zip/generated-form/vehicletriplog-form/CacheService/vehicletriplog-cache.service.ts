// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IVehicleTripLogDto } from '../../../../models/generatedtypes';
import { VehicleTripLogRepository } from '../../../../services/generated/vehicletriplog-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class VehicleTripLogCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new VehicleTripLogRepository(http, configurations, injector);
  }

  data: IVehicleTripLogDto[] = [];
  dataSource: VehicleTripLogRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    distance: new FormControl(''),
    started: new FormControl(''),
    ended: new FormControl(''),
    odometerStart: new FormControl(''),
    odometerEnd: new FormControl(''),
    description: new FormControl(''),
    startedAt: new FormControl(''),
    endedAt: new FormControl(''),
    title: new FormControl(''),
    fuelConsumption: new FormControl(''),
    estimatedDistance: new FormControl(''),
    estimatedTime: new FormControl(''),
    durationInMinutes: new FormControl(''),
    latestAccOnTime: new FormControl(''),
    suggestedRoute: new FormControl(''),
    actualRoute: new FormControl(''),
    day: new FormControl(''),
    month: new FormControl(''),
    year: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    distance: '',
    started: '',
    ended: '',
    odometerStart: '',
    odometerEnd: '',
    description: '',
    startedAt: '',
    endedAt: '',
    title: '',
    fuelConsumption: '',
    estimatedDistance: '',
    estimatedTime: '',
    durationInMinutes: '',
    latestAccOnTime: '',
    suggestedRoute: '',
    actualRoute: '',
    day: '',
    month: '',
    year: '',
    });
  }

  populateForm(vehicleTripLog) {
     this.form.setValue(vehicleTripLog);
  }

  getVehicleTripLogs() {

  }

  insertVehicleTripLog(vehicleTripLog) {

  }

  updateVehicleTripLog(vehicleTripLog) {

  }

  deleteVehicleTripLog(id: number) {

  }
}



