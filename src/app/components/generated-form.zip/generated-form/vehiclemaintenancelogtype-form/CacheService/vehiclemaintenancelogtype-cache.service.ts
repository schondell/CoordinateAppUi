// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IVehicleMaintenanceLogTypeDto } from '../../../../models/generatedtypes';
import { VehicleMaintenanceLogTypeRepository } from '../../../../services/generated/vehiclemaintenancelogtype-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class VehicleMaintenanceLogTypeCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new VehicleMaintenanceLogTypeRepository(http, configurations, injector);
  }

  data: IVehicleMaintenanceLogTypeDto[] = [];
  dataSource: VehicleMaintenanceLogTypeRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    description: new FormControl(''),
    title: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    description: '',
    title: '',
    });
  }

  populateForm(vehicleMaintenanceLogType) {
     this.form.setValue(vehicleMaintenanceLogType);
  }

  getVehicleMaintenanceLogTypes() {

  }

  insertVehicleMaintenanceLogType(vehicleMaintenanceLogType) {

  }

  updateVehicleMaintenanceLogType(vehicleMaintenanceLogType) {

  }

  deleteVehicleMaintenanceLogType(id: number) {

  }
}



