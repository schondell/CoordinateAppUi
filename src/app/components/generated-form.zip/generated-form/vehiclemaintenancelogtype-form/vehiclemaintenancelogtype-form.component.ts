// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { VehicleMaintenanceLogTypeDto } from 'src/app/models/generatedtypes';
import { VehicleMaintenanceLogTypeCacheService } from './CacheService/vehiclemaintenancelogtype-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { VehicleMaintenanceLogTypeRepository } from 'src/app/services/generated/vehiclemaintenancelogtype-repository';

@Component({
  selector: 'app-vehiclemaintenancelogtype-form',
  templateUrl: './vehiclemaintenancelogtype-form.component.html',
  styleUrls: ['./vehiclemaintenancelogtype-form.component.css'],
  animations: [fadeInOut]
})
export class VehicleMaintenanceLogTypeFormComponent implements OnInit {


// column VehicleMaintenanceLogTypeId
	vehicleMaintenanceLogTypeIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getVehicleMaintenanceLogTypes();
		this.vehicleMaintenanceLogTypeIdRepository.getVehicleMaintenanceLogTypesDropDownItems().subscribe(data => this.vehicleMaintenanceLogTypeIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: VehicleMaintenanceLogTypeCacheService,
    private alertService: AlertService,
		private vehicleMaintenanceLogTypeIdRepository: VehicleMaintenanceLogTypeRepository,
    public dialogRef: MatDialogRef<VehicleMaintenanceLogTypeFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new VehicleMaintenanceLogTypeDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertVehicleMaintenanceLogType(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
