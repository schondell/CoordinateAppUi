// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IGpsTrackerTypeDto } from '../../../../models/generatedtypes';
import { GpsTrackerTypeRepository } from '../../../../services/generated/gpstrackertype-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class GpsTrackerTypeCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new GpsTrackerTypeRepository(http, configurations, injector);
  }

  data: IGpsTrackerTypeDto[] = [];
  dataSource: GpsTrackerTypeRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    order: new FormControl(''),
    description: new FormControl(''),
    isObd2: new FormControl(''),
    defaultPassword: new FormControl(''),
    vendorUrl: new FormControl(''),
    dataSheetUrl: new FormControl(''),
    protocolDocUrl: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    order: '',
    description: '',
    isObd2: '',
    defaultPassword: '',
    vendorUrl: '',
    dataSheetUrl: '',
    protocolDocUrl: '',
    });
  }

  populateForm(gpsTrackerType) {
     this.form.setValue(gpsTrackerType);
  }

  getGpsTrackerTypes() {

  }

  insertGpsTrackerType(gpsTrackerType) {

  }

  updateGpsTrackerType(gpsTrackerType) {

  }

  deleteGpsTrackerType(id: number) {

  }
}



