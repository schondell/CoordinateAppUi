// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { GpsTrackerTypeDto } from 'src/app/models/generatedtypes';
import { GpsTrackerTypeCacheService } from './CacheService/gpstrackertype-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { GpsTrackerTypeRepository } from 'src/app/services/generated/gpstrackertype-repository';

@Component({
  selector: 'app-gpstrackertype-form',
  templateUrl: './gpstrackertype-form.component.html',
  styleUrls: ['./gpstrackertype-form.component.css'],
  animations: [fadeInOut]
})
export class GpsTrackerTypeFormComponent implements OnInit {


// column GpsTrackerTypeId
	gpsTrackerTypeIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getGpsTrackerTypes();
		this.gpsTrackerTypeIdRepository.getGpsTrackerTypesDropDownItems().subscribe(data => this.gpsTrackerTypeIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: GpsTrackerTypeCacheService,
    private alertService: AlertService,
		private gpsTrackerTypeIdRepository: GpsTrackerTypeRepository,
    public dialogRef: MatDialogRef<GpsTrackerTypeFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new GpsTrackerTypeDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertGpsTrackerType(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
