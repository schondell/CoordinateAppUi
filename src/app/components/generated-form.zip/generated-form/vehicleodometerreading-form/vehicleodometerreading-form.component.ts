// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { VehicleOdometerReadingDto } from 'src/app/models/generatedtypes';
import { VehicleOdometerReadingCacheService } from './CacheService/vehicleodometerreading-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { VehicleOdometerReadingRepository } from 'src/app/services/generated/vehicleodometerreading-repository';
import { VehicleRepository } from 'src/app/services/generated/vehicle-repository';

@Component({
  selector: 'app-vehicleodometerreading-form',
  templateUrl: './vehicleodometerreading-form.component.html',
  styleUrls: ['./vehicleodometerreading-form.component.css'],
  animations: [fadeInOut]
})
export class VehicleOdometerReadingFormComponent implements OnInit {


// column VehicleOdometerReadingId
	vehicleOdometerReadingIds: IDropDownItem[] =  new Array();

// column VehicleId
	vehicleIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getVehicleOdometerReadings();
		this.vehicleOdometerReadingIdRepository.getVehicleOdometerReadingsDropDownItems().subscribe(data => this.vehicleOdometerReadingIds = data);
		this.vehicleIdRepository.getVehiclesDropDownItems().subscribe(data => this.vehicleIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: VehicleOdometerReadingCacheService,
    private alertService: AlertService,
		private vehicleOdometerReadingIdRepository: VehicleOdometerReadingRepository,
		private vehicleIdRepository: VehicleRepository,
    public dialogRef: MatDialogRef<VehicleOdometerReadingFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new VehicleOdometerReadingDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertVehicleOdometerReading(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
