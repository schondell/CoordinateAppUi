// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IVehicleOdometerReadingDto } from '../../../../models/generatedtypes';
import { VehicleOdometerReadingRepository } from '../../../../services/generated/vehicleodometerreading-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class VehicleOdometerReadingCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new VehicleOdometerReadingRepository(http, configurations, injector);
  }

  data: IVehicleOdometerReadingDto[] = [];
  dataSource: VehicleOdometerReadingRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    reading: new FormControl(''),
    unitIdentity: new FormControl(''),
    trackerValue: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    reading: '',
    unitIdentity: '',
    trackerValue: '',
    });
  }

  populateForm(vehicleOdometerReading) {
     this.form.setValue(vehicleOdometerReading);
  }

  getVehicleOdometerReadings() {

  }

  insertVehicleOdometerReading(vehicleOdometerReading) {

  }

  updateVehicleOdometerReading(vehicleOdometerReading) {

  }

  deleteVehicleOdometerReading(id: number) {

  }
}



