// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IAddressDto } from '../../../../models/generatedtypes';
import { AddressRepository } from '../../../../services/generated/address-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class AddressCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new AddressRepository(http, configurations, injector);
  }

  data: IAddressDto[] = [];
  dataSource: AddressRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    address1: new FormControl(''),
    address2: new FormControl(''),
    address3: new FormControl(''),
    city: new FormControl(''),
    zip: new FormControl(''),
    state: new FormControl(''),
    country: new FormControl(''),
    normalizedAddress: new FormControl(''),
    searchFormat: new FormControl(''),
    timeZone: new FormControl(''),
    description: new FormControl(''),
    provider: new FormControl(''),
    createdForVehicle: new FormControl(''),
    firstTime: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    address1: '',
    address2: '',
    address3: '',
    city: '',
    zip: '',
    state: '',
    country: '',
    normalizedAddress: '',
    searchFormat: '',
    timeZone: '',
    description: '',
    provider: '',
    createdForVehicle: '',
    firstTime: '',
    });
  }

  populateForm(address) {
     this.form.setValue(address);
  }

  getAddresss() {

  }

  insertAddress(address) {

  }

  updateAddress(address) {

  }

  deleteAddress(id: number) {

  }
}



