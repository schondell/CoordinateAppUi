// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { ResourceDto } from 'src/app/models/generatedtypes';
import { ResourceCacheService } from './CacheService/resource-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { ResourceRepository } from 'src/app/services/generated/resource-repository';
import { UserRepository } from 'src/app/services/generated/user-repository';
import { AddressRepository } from 'src/app/services/generated/address-repository';
import { ResourceTypeRepository } from 'src/app/services/generated/resourcetype-repository';

@Component({
  selector: 'app-resource-form',
  templateUrl: './resource-form.component.html',
  styleUrls: ['./resource-form.component.css'],
  animations: [fadeInOut]
})
export class ResourceFormComponent implements OnInit {


// column ResourceId
	resourceIds: IDropDownItem[] =  new Array();

// column AssignedToUser
	assignedToUserIds: IDropDownItem[] =  new Array();

// column AddressId
	addressIds: IDropDownItem[] =  new Array();

// column ResourceTypeId
	resourceTypeIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getResources();
		this.resourceIdRepository.getResourcesDropDownItems().subscribe(data => this.resourceIds = data);
		this.assignedToUserIdRepository.getUsersDropDownItems().subscribe(data => this.assignedToUserIds = data);
		this.addressIdRepository.getAddresssDropDownItems().subscribe(data => this.addressIds = data);
		this.resourceTypeIdRepository.getResourceTypesDropDownItems().subscribe(data => this.resourceTypeIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: ResourceCacheService,
    private alertService: AlertService,
		private resourceIdRepository: ResourceRepository,
		private assignedToUserIdRepository: UserRepository,
		private addressIdRepository: AddressRepository,
		private resourceTypeIdRepository: ResourceTypeRepository,
    public dialogRef: MatDialogRef<ResourceFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new ResourceDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertResource(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
