// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IResourceDto } from '../../../../models/generatedtypes';
import { ResourceRepository } from '../../../../services/generated/resource-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class ResourceCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new ResourceRepository(http, configurations, injector);
  }

  data: IResourceDto[] = [];
  dataSource: ResourceRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    availableFrom: new FormControl(''),
    availableTo: new FormControl(''),
    description: new FormControl(''),
    isActive: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    availableFrom: '',
    availableTo: '',
    description: '',
    isActive: '',
    });
  }

  populateForm(resource) {
     this.form.setValue(resource);
  }

  getResources() {

  }

  insertResource(resource) {

  }

  updateResource(resource) {

  }

  deleteResource(id: number) {

  }
}



