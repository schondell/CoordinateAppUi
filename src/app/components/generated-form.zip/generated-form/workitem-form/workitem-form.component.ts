// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { WorkItemDto } from 'src/app/models/generatedtypes';
import { WorkItemCacheService } from './CacheService/workitem-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { WorkItemRepository } from 'src/app/services/generated/workitem-repository';
import { WorkItemTypeRepository } from 'src/app/services/generated/workitemtype-repository';
import { CustomerRepository } from 'src/app/services/generated/customer-repository';
import { SprintRepository } from 'src/app/services/generated/sprint-repository';
import { UserRepository } from 'src/app/services/generated/user-repository';
import { WorkItemStatusRepository } from 'src/app/services/generated/workitemstatus-repository';
import { WorkItemPriorityRepository } from 'src/app/services/generated/workitempriority-repository';

@Component({
  selector: 'app-workitem-form',
  templateUrl: './workitem-form.component.html',
  styleUrls: ['./workitem-form.component.css'],
  animations: [fadeInOut]
})
export class WorkItemFormComponent implements OnInit {


// column WorkItemId
	workItemIds: IDropDownItem[] =  new Array();

// column WorkItemTypeId
	workItemTypeIds: IDropDownItem[] =  new Array();

// column CustomerId
	customerIds: IDropDownItem[] =  new Array();

// column SprintId
	sprintIds: IDropDownItem[] =  new Array();

// column AssignedToUser
	assignedToUserIds: IDropDownItem[] =  new Array();

// column WorkItemStatusId
	workItemStatusIds: IDropDownItem[] =  new Array();

// column WorkItemPriorityId
	workItemPriorityIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getWorkItems();
		this.workItemIdRepository.getWorkItemsDropDownItems().subscribe(data => this.workItemIds = data);
		this.workItemTypeIdRepository.getWorkItemTypesDropDownItems().subscribe(data => this.workItemTypeIds = data);
		this.customerIdRepository.getCustomersDropDownItems().subscribe(data => this.customerIds = data);
		this.sprintIdRepository.getSprintsDropDownItems().subscribe(data => this.sprintIds = data);
		this.assignedToUserIdRepository.getUsersDropDownItems().subscribe(data => this.assignedToUserIds = data);
		this.workItemStatusIdRepository.getWorkItemStatussDropDownItems().subscribe(data => this.workItemStatusIds = data);
		this.workItemPriorityIdRepository.getWorkItemPrioritysDropDownItems().subscribe(data => this.workItemPriorityIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: WorkItemCacheService,
    private alertService: AlertService,
		private workItemIdRepository: WorkItemRepository,
		private workItemTypeIdRepository: WorkItemTypeRepository,
		private customerIdRepository: CustomerRepository,
		private sprintIdRepository: SprintRepository,
		private assignedToUserIdRepository: UserRepository,
		private workItemStatusIdRepository: WorkItemStatusRepository,
		private workItemPriorityIdRepository: WorkItemPriorityRepository,
    public dialogRef: MatDialogRef<WorkItemFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new WorkItemDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertWorkItem(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
