// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IWorkItemDto } from '../../../../models/generatedtypes';
import { WorkItemRepository } from '../../../../services/generated/workitem-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';
import {AuthService} from "../../../../services/auth.service";

@Injectable({providedIn: 'root'})
export class WorkItemCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, authService: AuthService) {
    this.dataSource = new WorkItemRepository(configurations, http, authService);
  }

  data: IWorkItemDto[] = [];
  dataSource: WorkItemRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    title: new FormControl(''),
    description: new FormControl(''),
    estimatedWork: new FormControl(''),
    workDone: new FormControl(''),
    estimatedStart: new FormControl(''),
    isPlanned: new FormControl(''),
    travelTime: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    title: '',
    description: '',
    estimatedWork: '',
    workDone: '',
    estimatedStart: '',
    isPlanned: '',
    travelTime: '',
    });
  }

  populateForm(workItem) {
     this.form.setValue(workItem);
  }

  getWorkItems() {

  }

  insertWorkItem(workItem) {

  }

  updateWorkItem(workItem) {

  }

  deleteWorkItem(id: number) {

  }
}



