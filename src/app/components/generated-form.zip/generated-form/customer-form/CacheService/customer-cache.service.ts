// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ICustomerDto } from '../../../../models/generatedtypes';
import { CustomerRepository } from '../../../../services/generated/customer-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class CustomerCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new CustomerRepository(http, configurations, injector);
  }

  data: ICustomerDto[] = [];
  dataSource: CustomerRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    email: new FormControl(''),
    phone: new FormControl(''),
    contact: new FormControl(''),
    webUrl: new FormControl(''),
    vatNo: new FormControl(''),
    companyNo: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    email: '',
    phone: '',
    contact: '',
    webUrl: '',
    vatNo: '',
    companyNo: '',
    });
  }

  populateForm(customer) {
     this.form.setValue(customer);
  }

  getCustomers() {

  }

  insertCustomer(customer) {

  }

  updateCustomer(customer) {

  }

  deleteCustomer(id: number) {

  }
}



