// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { CustomerDto } from 'src/app/models/generatedtypes';
import { CustomerCacheService } from './CacheService/customer-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { CustomerRepository } from 'src/app/services/generated/customer-repository';
import { CustomerTypeRepository } from 'src/app/services/generated/customertype-repository';
import { AddressRepository } from 'src/app/services/generated/address-repository';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.css'],
  animations: [fadeInOut]
})
export class CustomerFormComponent implements OnInit {


// column CustomerId
	customerIds: IDropDownItem[] =  new Array();

// column CustomerTypeId
	customerTypeIds: IDropDownItem[] =  new Array();

// column AddressId
	addressIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getCustomers();
		this.customerIdRepository.getCustomersDropDownItems().subscribe(data => this.customerIds = data);
		this.customerTypeIdRepository.getCustomerTypesDropDownItems().subscribe(data => this.customerTypeIds = data);
		this.addressIdRepository.getAddresssDropDownItems().subscribe(data => this.addressIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: CustomerCacheService,
    private alertService: AlertService,
		private customerIdRepository: CustomerRepository,
		private customerTypeIdRepository: CustomerTypeRepository,
		private addressIdRepository: AddressRepository,
    public dialogRef: MatDialogRef<CustomerFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new CustomerDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertCustomer(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
