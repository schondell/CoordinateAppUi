// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ICustomerWithWorkItem3Dto } from '../../../../models/generatedtypes';
import { CustomerWithWorkItem3Repository } from '../../../../services/generated/customerwithworkitem3-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class CustomerWithWorkItem3CacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new CustomerWithWorkItem3Repository(http, configurations, injector);
  }

  data: ICustomerWithWorkItem3Dto[] = [];
  dataSource: CustomerWithWorkItem3Repository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    customerWithWorkItemNo: new FormControl(''),
    name: new FormControl(''),
    normalizedAddress: new FormControl(''),
    workItemTitle: new FormControl(''),
    description: new FormControl(''),
    modifiedByUserNo: new FormControl(''),
    createdByUserNo: new FormControl(''),
    priority: new FormControl(''),
    status: new FormControl(''),
    assignedToUserNo: new FormControl(''),
    phone: new FormControl(''),
    email: new FormControl(''),
    contact: new FormControl(''),
    estimatedStart: new FormControl(''),
    isPlanned: new FormControl(''),
    largeThumbUrl: new FormControl(''),
    smallThumbUrl: new FormControl(''),
    comment: new FormControl(''),
    workItemStatus: new FormControl(''),
    workItemBaseStatusNo: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    customerWithWorkItemNo: '',
    name: '',
    normalizedAddress: '',
    workItemTitle: '',
    description: '',
    modifiedByUserNo: '',
    createdByUserNo: '',
    priority: '',
    status: '',
    assignedToUserNo: '',
    phone: '',
    email: '',
    contact: '',
    estimatedStart: '',
    isPlanned: '',
    largeThumbUrl: '',
    smallThumbUrl: '',
    comment: '',
    workItemStatus: '',
    workItemBaseStatusNo: '',
    });
  }

  populateForm(customerWithWorkItem3) {
     this.form.setValue(customerWithWorkItem3);
  }

  getCustomerWithWorkItem3s() {

  }

  insertCustomerWithWorkItem3(customerWithWorkItem3) {

  }

  updateCustomerWithWorkItem3(customerWithWorkItem3) {

  }

  deleteCustomerWithWorkItem3(id: number) {

  }
}



