// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ICountryDto } from '../../../../models/generatedtypes';
import { CountryRepository } from '../../../../services/generated/country-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class CountryCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new CountryRepository(http, configurations, injector);
  }

  data: ICountryDto[] = [];
  dataSource: CountryRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    internationalCode: new FormControl(''),
    name: new FormControl(''),
    iSOCOde: new FormControl(''),
    localName: new FormControl(''),
    processed: new FormControl(''),
    isProcessed: new FormControl(''),
    ignore: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    internationalCode: '',
    name: '',
    iSOCOde: '',
    localName: '',
    processed: '',
    isProcessed: '',
    ignore: '',
    });
  }

  populateForm(country) {
     this.form.setValue(country);
  }

  getCountrys() {

  }

  insertCountry(country) {

  }

  updateCountry(country) {

  }

  deleteCountry(id: number) {

  }
}



