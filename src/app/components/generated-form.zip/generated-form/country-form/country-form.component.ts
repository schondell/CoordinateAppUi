// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { CountryDto } from 'src/app/models/generatedtypes';
import { CountryCacheService } from './CacheService/country-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { CountryRepository } from 'src/app/services/generated/country-repository';

@Component({
  selector: 'app-country-form',
  templateUrl: './country-form.component.html',
  styleUrls: ['./country-form.component.css'],
  animations: [fadeInOut]
})
export class CountryFormComponent implements OnInit {


// column CountryId
	countryIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getCountrys();
		this.countryIdRepository.getCountrysDropDownItems().subscribe(data => this.countryIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: CountryCacheService,
    private alertService: AlertService,
		private countryIdRepository: CountryRepository,
    public dialogRef: MatDialogRef<CountryFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new CountryDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertCountry(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
