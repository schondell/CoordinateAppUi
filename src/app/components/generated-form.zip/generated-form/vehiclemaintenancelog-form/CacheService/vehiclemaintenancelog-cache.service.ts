// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IVehicleMaintenanceLogDto } from '../../../../models/generatedtypes';
import { VehicleMaintenanceLogRepository } from '../../../../services/generated/vehiclemaintenancelog-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class VehicleMaintenanceLogCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new VehicleMaintenanceLogRepository(http, configurations, injector);
  }

  data: IVehicleMaintenanceLogDto[] = [];
  dataSource: VehicleMaintenanceLogRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    odometerReading: new FormControl(''),
    description: new FormControl(''),
    title: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    odometerReading: '',
    description: '',
    title: '',
    });
  }

  populateForm(vehicleMaintenanceLog) {
     this.form.setValue(vehicleMaintenanceLog);
  }

  getVehicleMaintenanceLogs() {

  }

  insertVehicleMaintenanceLog(vehicleMaintenanceLog) {

  }

  updateVehicleMaintenanceLog(vehicleMaintenanceLog) {

  }

  deleteVehicleMaintenanceLog(id: number) {

  }
}



