// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { CustomerWithAssignedWorkItemDto } from 'src/app/models/generatedtypes';
import { CustomerWithAssignedWorkItemCacheService } from './CacheService/customerwithassignedworkitem-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { CustomerWithAssignedWorkItemRepository } from 'src/app/services/generated/customerwithassignedworkitem-repository';
import { WorkItemBaseStatusRepository } from 'src/app/services/generated/workitembasestatus-repository';

@Component({
  selector: 'app-customerwithassignedworkitem-form',
  templateUrl: './customerwithassignedworkitem-form.component.html',
  styleUrls: ['./customerwithassignedworkitem-form.component.css'],
  animations: [fadeInOut]
})
export class CustomerWithAssignedWorkItemFormComponent implements OnInit {


// column CustomerWithAssignedWorkItemId
	customerWithAssignedWorkItemIds: IDropDownItem[] =  new Array();

// column WorkItemBaseStatusId
	workItemBaseStatusIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getCustomerWithAssignedWorkItems();
		this.customerWithAssignedWorkItemIdRepository.getCustomerWithAssignedWorkItemsDropDownItems().subscribe(data => this.customerWithAssignedWorkItemIds = data);
		this.workItemBaseStatusIdRepository.getWorkItemBaseStatussDropDownItems().subscribe(data => this.workItemBaseStatusIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: CustomerWithAssignedWorkItemCacheService,
    private alertService: AlertService,
		private customerWithAssignedWorkItemIdRepository: CustomerWithAssignedWorkItemRepository,
		private workItemBaseStatusIdRepository: WorkItemBaseStatusRepository,
    public dialogRef: MatDialogRef<CustomerWithAssignedWorkItemFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new CustomerWithAssignedWorkItemDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertCustomerWithAssignedWorkItem(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
