// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ICustomerWithAssignedWorkItemDto } from '../../../../models/generatedtypes';
import { CustomerWithAssignedWorkItemRepository } from '../../../../services/generated/customerwithassignedworkitem-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class CustomerWithAssignedWorkItemCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new CustomerWithAssignedWorkItemRepository(http, configurations, injector);
  }

  data: ICustomerWithAssignedWorkItemDto[] = [];
  dataSource: CustomerWithAssignedWorkItemRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    normalizedAddress: new FormControl(''),
    workItemTitle: new FormControl(''),
    description: new FormControl(''),
    priority: new FormControl(''),
    status: new FormControl(''),
    workItemIdentity: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    normalizedAddress: '',
    workItemTitle: '',
    description: '',
    priority: '',
    status: '',
    workItemIdentity: '',
    });
  }

  populateForm(customerWithAssignedWorkItem) {
     this.form.setValue(customerWithAssignedWorkItem);
  }

  getCustomerWithAssignedWorkItems() {

  }

  insertCustomerWithAssignedWorkItem(customerWithAssignedWorkItem) {

  }

  updateCustomerWithAssignedWorkItem(customerWithAssignedWorkItem) {

  }

  deleteCustomerWithAssignedWorkItem(id: number) {

  }
}



