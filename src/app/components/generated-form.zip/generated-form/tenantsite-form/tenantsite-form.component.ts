// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { TenantSiteDto } from 'src/app/models/generatedtypes';
import { TenantSiteCacheService } from './CacheService/tenantsite-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { TenantSiteRepository } from 'src/app/services/generated/tenantsite-repository';
import { AddressRepository } from 'src/app/services/generated/address-repository';

@Component({
  selector: 'app-tenantsite-form',
  templateUrl: './tenantsite-form.component.html',
  styleUrls: ['./tenantsite-form.component.css'],
  animations: [fadeInOut]
})
export class TenantSiteFormComponent implements OnInit {


// column TenantSiteId
	tenantSiteIds: IDropDownItem[] =  new Array();

// column AddressId
	addressIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getTenantSites();
		this.tenantSiteIdRepository.getTenantSitesDropDownItems().subscribe(data => this.tenantSiteIds = data);
		this.addressIdRepository.getAddresssDropDownItems().subscribe(data => this.addressIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: TenantSiteCacheService,
    private alertService: AlertService,
		private tenantSiteIdRepository: TenantSiteRepository,
		private addressIdRepository: AddressRepository,
    public dialogRef: MatDialogRef<TenantSiteFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new TenantSiteDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertTenantSite(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
