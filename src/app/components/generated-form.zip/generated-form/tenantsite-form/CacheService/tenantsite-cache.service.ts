// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ITenantSiteDto } from '../../../../models/generatedtypes';
import { TenantSiteRepository } from '../../../../services/generated/tenantsite-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class TenantSiteCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new TenantSiteRepository(http, configurations, injector);
  }

  data: ITenantSiteDto[] = [];
  dataSource: TenantSiteRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    userTitle: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    userTitle: '',
    });
  }

  populateForm(tenantSite) {
     this.form.setValue(tenantSite);
  }

  getTenantSites() {

  }

  insertTenantSite(tenantSite) {

  }

  updateTenantSite(tenantSite) {

  }

  deleteTenantSite(id: number) {

  }
}



