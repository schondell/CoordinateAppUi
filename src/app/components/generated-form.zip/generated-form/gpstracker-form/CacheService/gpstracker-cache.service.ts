// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IGpsTrackerDto } from '../../../../models/generatedtypes';
import { GpsTrackerRepository } from '../../../../services/generated/gpstracker-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class GpsTrackerCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new GpsTrackerRepository(http, configurations, injector);
  }

  data: IGpsTrackerDto[] = [];
  dataSource: GpsTrackerRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    trackerIdentification: new FormControl(''),
    imeNumber: new FormControl(''),
    description: new FormControl(''),
    isActive: new FormControl(''),
    trackerPassword: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    trackerIdentification: '',
    imeNumber: '',
    description: '',
    isActive: '',
    trackerPassword: '',
    });
  }

  populateForm(gpsTracker) {
     this.form.setValue(gpsTracker);
  }

  getGpsTrackers() {

  }

  insertGpsTracker(gpsTracker) {

  }

  updateGpsTracker(gpsTracker) {

  }

  deleteGpsTracker(id: number) {

  }
}



