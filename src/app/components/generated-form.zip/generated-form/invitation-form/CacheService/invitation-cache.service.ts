// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IInvitationDto } from '../../../../models/generatedtypes';
import { InvitationRepository } from '../../../../services/generated/invitation-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class InvitationCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new InvitationRepository(http, configurations, injector);
  }

  data: IInvitationDto[] = [];
  dataSource: InvitationRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    email: new FormControl(''),
    invitedFromIp: new FormControl(''),
    invitationAccepted: new FormControl(''),
    invitedAt: new FormControl(''),
    acceptedAt: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    email: '',
    invitedFromIp: '',
    invitationAccepted: '',
    invitedAt: '',
    acceptedAt: '',
    });
  }

  populateForm(invitation) {
     this.form.setValue(invitation);
  }

  getInvitations() {

  }

  insertInvitation(invitation) {

  }

  updateInvitation(invitation) {

  }

  deleteInvitation(id: number) {

  }
}



