// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IUserTypeDto } from '../../../../models/generatedtypes';
import { UserTypeRepository } from '../../../../services/generated/usertype-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class UserTypeCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new UserTypeRepository(http, configurations, injector);
  }

  data: IUserTypeDto[] = [];
  dataSource: UserTypeRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    description: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    description: '',
    });
  }

  populateForm(userType) {
     this.form.setValue(userType);
  }

  getUserTypes() {

  }

  insertUserType(userType) {

  }

  updateUserType(userType) {

  }

  deleteUserType(id: number) {

  }
}



