// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { VehicleTripTypeDto } from 'src/app/models/generatedtypes';
import { VehicleTripTypeCacheService } from './CacheService/vehicletriptype-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { VehicleTripTypeRepository } from 'src/app/services/generated/vehicletriptype-repository';
import { VehicleTripBaseTypeRepository } from 'src/app/services/generated/vehicletripbasetype-repository';

@Component({
  selector: 'app-vehicletriptype-form',
  templateUrl: './vehicletriptype-form.component.html',
  styleUrls: ['./vehicletriptype-form.component.css'],
  animations: [fadeInOut]
})
export class VehicleTripTypeFormComponent implements OnInit {


// column VehicleTripTypeId
	vehicleTripTypeIds: IDropDownItem[] =  new Array();

// column VehicleTripBaseTypeId
	vehicleTripBaseTypeIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getVehicleTripTypes();
		this.vehicleTripTypeIdRepository.getVehicleTripTypesDropDownItems().subscribe(data => this.vehicleTripTypeIds = data);
		this.vehicleTripBaseTypeIdRepository.getVehicleTripBaseTypesDropDownItems().subscribe(data => this.vehicleTripBaseTypeIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: VehicleTripTypeCacheService,
    private alertService: AlertService,
		private vehicleTripTypeIdRepository: VehicleTripTypeRepository,
		private vehicleTripBaseTypeIdRepository: VehicleTripBaseTypeRepository,
    public dialogRef: MatDialogRef<VehicleTripTypeFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new VehicleTripTypeDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertVehicleTripType(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
