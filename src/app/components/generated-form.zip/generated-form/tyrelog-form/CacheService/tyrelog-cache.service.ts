// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ITyreLogDto } from '../../../../models/generatedtypes';
import { TyreLogRepository } from '../../../../services/generated/tyrelog-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class TyreLogCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new TyreLogRepository(http, configurations, injector);
  }

  data: ITyreLogDto[] = [];
  dataSource: TyreLogRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    odometerReading: new FormControl(''),
    description: new FormControl(''),
    title: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    odometerReading: '',
    description: '',
    title: '',
    });
  }

  populateForm(tyreLog) {
     this.form.setValue(tyreLog);
  }

  getTyreLogs() {

  }

  insertTyreLog(tyreLog) {

  }

  updateTyreLog(tyreLog) {

  }

  deleteTyreLog(id: number) {

  }
}



