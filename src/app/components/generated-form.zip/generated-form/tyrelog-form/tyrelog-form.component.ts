// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { TyreLogDto } from 'src/app/models/generatedtypes';
import { TyreLogCacheService } from './CacheService/tyrelog-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { TyreLogRepository } from 'src/app/services/generated/tyrelog-repository';
import { VehicleMaintenanceLogTypeRepository } from 'src/app/services/generated/vehiclemaintenancelogtype-repository';
import { VehicleRepository } from 'src/app/services/generated/vehicle-repository';

@Component({
  selector: 'app-tyrelog-form',
  templateUrl: './tyrelog-form.component.html',
  styleUrls: ['./tyrelog-form.component.css'],
  animations: [fadeInOut]
})
export class TyreLogFormComponent implements OnInit {


// column TyreLogId
	tyreLogIds: IDropDownItem[] =  new Array();

// column VehicleMaintenanceLogTypeId
	vehicleMaintenanceLogTypeIds: IDropDownItem[] =  new Array();

// column VehicleId
	vehicleIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getTyreLogs();
		this.tyreLogIdRepository.getTyreLogsDropDownItems().subscribe(data => this.tyreLogIds = data);
		this.vehicleMaintenanceLogTypeIdRepository.getVehicleMaintenanceLogTypesDropDownItems().subscribe(data => this.vehicleMaintenanceLogTypeIds = data);
		this.vehicleIdRepository.getVehiclesDropDownItems().subscribe(data => this.vehicleIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: TyreLogCacheService,
    private alertService: AlertService,
		private tyreLogIdRepository: TyreLogRepository,
		private vehicleMaintenanceLogTypeIdRepository: VehicleMaintenanceLogTypeRepository,
		private vehicleIdRepository: VehicleRepository,
    public dialogRef: MatDialogRef<TyreLogFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new TyreLogDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertTyreLog(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
