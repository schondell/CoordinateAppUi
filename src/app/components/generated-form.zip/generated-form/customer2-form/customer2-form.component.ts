// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { Customer2Dto } from 'src/app/models/generatedtypes';
import { Customer2CacheService } from './CacheService/customer2-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { Customer2Repository } from 'src/app/services/generated/customer2-repository';

@Component({
  selector: 'app-customer2-form',
  templateUrl: './customer2-form.component.html',
  styleUrls: ['./customer2-form.component.css'],
  animations: [fadeInOut]
})
export class Customer2FormComponent implements OnInit {


// column Customer2Id
	customer2Ids: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getCustomer2s();
		this.customer2IdRepository.getCustomer2sDropDownItems().subscribe(data => this.customer2Ids = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: Customer2CacheService,
    private alertService: AlertService,
		private customer2IdRepository: Customer2Repository,
    public dialogRef: MatDialogRef<Customer2FormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new Customer2Dto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertCustomer2(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
