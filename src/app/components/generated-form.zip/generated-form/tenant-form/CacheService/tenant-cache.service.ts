// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ITenantDto } from '../../../../models/generatedtypes';
import { TenantRepository } from '../../../../services/generated/tenant-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class TenantCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new TenantRepository(http, configurations, injector);
  }

  data: ITenantDto[] = [];
  dataSource: TenantRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    webUrl: new FormControl(''),
    eventHubName: new FormControl(''),
    saS: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    webUrl: '',
    eventHubName: '',
    saS: '',
    });
  }

  populateForm(tenant) {
     this.form.setValue(tenant);
  }

  getTenants() {

  }

  insertTenant(tenant) {

  }

  updateTenant(tenant) {

  }

  deleteTenant(id: number) {

  }
}



