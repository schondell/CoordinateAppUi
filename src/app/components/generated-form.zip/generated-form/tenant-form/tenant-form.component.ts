// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { TenantDto } from 'src/app/models/generatedtypes';
import { TenantCacheService } from './CacheService/tenant-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { TenantTypeRepository } from 'src/app/services/generated/tenanttype-repository';
import { AddressRepository } from 'src/app/services/generated/address-repository';
import { UserRepository } from 'src/app/services/generated/user-repository';
import { RetailerTypeRepository } from 'src/app/services/generated/retailertype-repository';

@Component({
  selector: 'app-tenant-form',
  templateUrl: './tenant-form.component.html',
  styleUrls: ['./tenant-form.component.css'],
  animations: [fadeInOut]
})
export class TenantFormComponent implements OnInit {


// column TenantTypeId
	tenantTypeIds: IDropDownItem[] =  new Array();

// column AddressId
	addressIds: IDropDownItem[] =  new Array();

// column AdminUser
	adminUserIds: IDropDownItem[] =  new Array();

// column RetailerTypeId
	retailerTypeIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getTenants();
		this.tenantTypeIdRepository.getTenantTypesDropDownItems().subscribe(data => this.tenantTypeIds = data);
		this.addressIdRepository.getAddresssDropDownItems().subscribe(data => this.addressIds = data);
		this.adminUserIdRepository.getUsersDropDownItems().subscribe(data => this.adminUserIds = data);
		this.retailerTypeIdRepository.getRetailerTypesDropDownItems().subscribe(data => this.retailerTypeIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: TenantCacheService,
    private alertService: AlertService,
		private tenantTypeIdRepository: TenantTypeRepository,
		private addressIdRepository: AddressRepository,
		private adminUserIdRepository: UserRepository,
		private retailerTypeIdRepository: RetailerTypeRepository,
    public dialogRef: MatDialogRef<TenantFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new TenantDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertTenant(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
