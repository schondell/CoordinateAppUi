// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ISimCardDto } from '../../../../models/generatedtypes';
import { SimCardRepository } from '../../../../services/generated/simcard-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class SimCardCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new SimCardRepository(http, configurations, injector);
  }

  data: ISimCardDto[] = [];
  dataSource: SimCardRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    iCCID: new FormControl(''),
    iMSI: new FormControl(''),
    mobileNumber: new FormControl(''),
    pUK: new FormControl(''),
    description: new FormControl(''),
    isActive: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    iCCID: '',
    iMSI: '',
    mobileNumber: '',
    pUK: '',
    description: '',
    isActive: '',
    });
  }

  populateForm(simCard) {
     this.form.setValue(simCard);
  }

  getSimCards() {

  }

  insertSimCard(simCard) {

  }

  updateSimCard(simCard) {

  }

  deleteSimCard(id: number) {

  }
}



