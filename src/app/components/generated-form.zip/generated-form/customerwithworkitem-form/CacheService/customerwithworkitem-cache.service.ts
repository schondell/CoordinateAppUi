// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ICustomerWithWorkItemDto } from '../../../../models/generatedtypes';
import { CustomerWithWorkItemRepository } from '../../../../services/generated/customerwithworkitem-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';
import {AuthConfig} from "angular-oauth2-oidc";
import {AuthService} from "../../../../services/auth.service";

@Injectable({providedIn: 'root'})
export class CustomerWithWorkItemCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, authService: AuthService) {
    this.dataSource = new CustomerWithWorkItemRepository(configurations, http, authService);
  }

  data: ICustomerWithWorkItemDto[] = [];
  dataSource: CustomerWithWorkItemRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    normalizedAddress: new FormControl(''),
    workItemTitle: new FormControl(''),
    description: new FormControl(''),
    priority: new FormControl(''),
    workItemIdentity: new FormControl(''),
    status: new FormControl(''),
    phone: new FormControl(''),
    email: new FormControl(''),
    contact: new FormControl(''),
    estimatedStart: new FormControl(''),
    isPlanned: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    normalizedAddress: '',
    workItemTitle: '',
    description: '',
    priority: '',
    workItemIdentity: '',
    status: '',
    phone: '',
    email: '',
    contact: '',
    estimatedStart: '',
    isPlanned: '',
    });
  }

  populateForm(customerWithWorkItem) {
     this.form.setValue(customerWithWorkItem);
  }

  getCustomerWithWorkItems() {

  }

  insertCustomerWithWorkItem(customerWithWorkItem) {

  }

  updateCustomerWithWorkItem(customerWithWorkItem) {

  }

  deleteCustomerWithWorkItem(id: number) {

  }
}



