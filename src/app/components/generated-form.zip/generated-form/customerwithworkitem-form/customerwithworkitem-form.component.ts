import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { CustomerWithWorkItemDto } from 'src/app/models/generatedtypes';
import { CustomerWithWorkItemCacheService } from './CacheService/customerwithworkitem-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { CustomerWithWorkItemRepository } from 'src/app/services/generated/customerwithworkitem-repository';
import { UserRepository } from 'src/app/services/generated/user-repository';
import { WorkItemBaseStatusRepository } from 'src/app/services/generated/workitembasestatus-repository';

@Component({
  selector: 'app-customerwithworkitem-form',
  templateUrl: './customerwithworkitem-form.component.html',
  styleUrls: ['./customerwithworkitem-form.component.css'],
  animations: [fadeInOut]
})
export class CustomerWithWorkItemFormComponent implements OnInit {

// column CustomerWithWorkItemId
  customerWithWorkItemIds: IDropDownItem[] =  [];

// column AssignedToUser
  assignedToUserIds: IDropDownItem[] =  [];

// column WorkItemBaseStatusId
  workItemBaseStatusIds: IDropDownItem[] =  [];

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getCustomerWithWorkItems();
    this.customerWithWorkItemIdRepository.getCustomerWithWorkItemsDropDownItems().subscribe(data => this.customerWithWorkItemIds = data);
    this.assignedToUserIdRepository.getUsersDropDownItems().subscribe(data => this.assignedToUserIds = data);
    this.workItemBaseStatusIdRepository.getWorkItemBaseStatussDropDownItems().subscribe(data => this.workItemBaseStatusIds = data);
  }

  constructor(private formBuilder: FormBuilder,
              public service: CustomerWithWorkItemCacheService,
              private alertService: AlertService,
              private customerWithWorkItemIdRepository: CustomerWithWorkItemRepository,
              private assignedToUserIdRepository: UserRepository,
              private workItemBaseStatusIdRepository: WorkItemBaseStatusRepository,
              public dialogRef: MatDialogRef<CustomerWithWorkItemFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new CustomerWithWorkItemDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertCustomerWithWorkItem(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
