// Auto-generated file, do not modify

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { VehicleDto } from 'src/app/models/generatedtypes';
import { VehicleCacheService } from './CacheService/vehicle-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { VehicleRepository } from 'src/app/services/generated/vehicle-repository';
import { ResourceRepository } from 'src/app/services/generated/resource-repository';
import { UserRepository } from 'src/app/services/generated/user-repository';
import { AddressRepository } from 'src/app/services/generated/address-repository';
import { VehicleTypeRepository } from 'src/app/services/generated/vehicletype-repository';
import { GpsTrackerRepository } from 'src/app/services/generated/gpstracker-repository';
import { TenantSiteRepository } from 'src/app/services/generated/tenantsite-repository';

@Component({
  selector: 'app-vehicle-form',
  templateUrl: './vehicle-form.component.html',
  styleUrls: ['./vehicle-form.component.css'],
  animations: [fadeInOut]
})
export class VehicleFormComponent implements OnInit {


// column VehicleId
	vehicleIds: IDropDownItem[] =  new Array();

// column ResourceId
	resourceIds: IDropDownItem[] =  new Array();

// column UserId
	userIds: IDropDownItem[] =  new Array();

// column AddressId
	addressIds: IDropDownItem[] =  new Array();

// column VehicleTypeId
	vehicleTypeIds: IDropDownItem[] =  new Array();

// column GpsTrackerId
	gpsTrackerIds: IDropDownItem[] =  new Array();

// column TenantSiteId
	tenantSiteIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getVehicles();
		this.vehicleIdRepository.getVehiclesDropDownItems().subscribe(data => this.vehicleIds = data);
		this.resourceIdRepository.getResourcesDropDownItems().subscribe(data => this.resourceIds = data);
		this.userIdRepository.getUsersDropDownItems().subscribe(data => this.userIds = data);
		this.addressIdRepository.getAddresssDropDownItems().subscribe(data => this.addressIds = data);
		this.vehicleTypeIdRepository.getVehicleTypesDropDownItems().subscribe(data => this.vehicleTypeIds = data);
		this.gpsTrackerIdRepository.getGpsTrackersDropDownItems().subscribe(data => this.gpsTrackerIds = data);
		this.tenantSiteIdRepository.getTenantSitesDropDownItems().subscribe(data => this.tenantSiteIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: VehicleCacheService,
    private alertService: AlertService,
		private vehicleIdRepository: VehicleRepository,
		private resourceIdRepository: ResourceRepository,
		private userIdRepository: UserRepository,
		private addressIdRepository: AddressRepository,
		private vehicleTypeIdRepository: VehicleTypeRepository,
		private gpsTrackerIdRepository: GpsTrackerRepository,
		private tenantSiteIdRepository: TenantSiteRepository,
    public dialogRef: MatDialogRef<VehicleFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new VehicleDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertVehicle(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
