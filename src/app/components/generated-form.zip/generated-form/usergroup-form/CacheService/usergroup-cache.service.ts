// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IUserGroupDto } from '../../../../models/generatedtypes';
import { UserGroupRepository } from '../../../../services/generated/usergroup-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class UserGroupCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector) {
    this.dataSource = new UserGroupRepository(http, configurations, injector);
  }

  data: IUserGroupDto[] = [];
  dataSource: UserGroupRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    name: new FormControl(''),
    description: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    name: '',
    description: '',
    });
  }

  populateForm(userGroup) {
     this.form.setValue(userGroup);
  }

  getUserGroups() {

  }

  insertUserGroup(userGroup) {

  }

  updateUserGroup(userGroup) {

  }

  deleteUserGroup(id: number) {

  }
}



