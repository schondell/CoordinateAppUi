// Auto-generated file, do not modify
//
import { Injectable, Injector } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { IVehicleTripLogFullDto } from '../../../../models/generatedtypes';
import { VehicleTripLogFullRepository } from '../../../../services/generated/vehicletriplogfull-repository';
import { ConfigurationService } from '../../../../services/configuration.service';
import { HttpClient } from '@angular/common/http';
import {AuthService} from "../../../../services/auth.service";

@Injectable({providedIn: 'root'})
export class VehicleTripLogFullCacheService {
  constructor(private datePipe: DatePipe, http: HttpClient, configurations: ConfigurationService, injector: Injector, authService: AuthService) {
    this.dataSource = new VehicleTripLogFullRepository(configurations, http,  authService);
  }

  data: IVehicleTripLogFullDto[] = [];
  dataSource: VehicleTripLogFullRepository | null;

  form: FormGroup = new FormGroup({
   // $key: new FormControl(null),
    started: new FormControl(''),
    ended: new FormControl(''),
    distance: new FormControl(''),
    odometerStart: new FormControl(''),
    odometerEnd: new FormControl(''),
    title: new FormControl(''),
    addressIdStart: new FormControl(''),
    addressIdEnd: new FormControl(''),
    fuelConsumption: new FormControl(''),
    duration: new FormControl(''),
    startAddressName: new FormControl(''),
    endAddressName: new FormControl(''),
    latestAccOnTime: new FormControl(''),
  });


  initializeFormGroup() {
    this.form.setValue({
    started: '',
    ended: '',
    distance: '',
    odometerStart: '',
    odometerEnd: '',
    title: '',
    addressIdStart: '',
    addressIdEnd: '',
    fuelConsumption: '',
    duration: '',
    startAddressName: '',
    endAddressName: '',
    latestAccOnTime: '',
    });
  }

  populateForm(vehicleTripLogFull) {
     this.form.setValue(vehicleTripLogFull);
  }

  getVehicleTripLogFulls() {

  }

  insertVehicleTripLogFull(vehicleTripLogFull) {

  }

  updateVehicleTripLogFull(vehicleTripLogFull) {

  }

  deleteVehicleTripLogFull(id: number) {

  }
}



