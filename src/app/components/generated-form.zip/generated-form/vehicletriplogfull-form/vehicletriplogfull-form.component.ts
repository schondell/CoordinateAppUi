import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { AlertService } from 'src/app/services/alert.service';
import { VehicleTripLogFullDto } from 'src/app/models/generatedtypes';
import { VehicleTripLogFullCacheService } from './CacheService/vehicletriplogfull-cache.service';
import { fadeInOut } from 'src/app/services/animations';
import { IDropDownItem } from 'src/app/models/DropDownItem';
import { VehicleTripLogFullRepository } from 'src/app/services/generated/vehicletriplogfull-repository';
import { VehicleTripTypeRepository } from 'src/app/services/generated/vehicletriptype-repository';

@Component({
  selector: 'app-vehicletriplogfull-form',
  templateUrl: './vehicletriplogfull-form.component.html',
  styleUrls: ['./vehicletriplogfull-form.component.css'],
  animations: [fadeInOut]
})
export class VehicleTripLogFullFormComponent implements OnInit {


// column VehicleTripLogFullId
	vehicleTripLogFullIds: IDropDownItem[] =  new Array();

// column VehicleTripTypeId
	vehicleTripTypeIds: IDropDownItem[] =  new Array();

  contactForm: FormGroup;

  ngOnInit(): void {
    this.service.getVehicleTripLogFulls();
		this.vehicleTripLogFullIdRepository.getVehicleTripLogFullsDropDownItems().subscribe(data => this.vehicleTripLogFullIds = data);
		this.vehicleTripTypeIdRepository.getVehicleTripTypesDropDownItems().subscribe(data => this.vehicleTripTypeIds = data);
  }

  constructor(private formBuilder: FormBuilder,
    public service: VehicleTripLogFullCacheService,
    private alertService: AlertService,
		private vehicleTripLogFullIdRepository: VehicleTripLogFullRepository,
		private vehicleTripTypeIdRepository: VehicleTripTypeRepository,
    public dialogRef: MatDialogRef<VehicleTripLogFullFormComponent>) {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  revert() {
    // Resets to blank object
    this.contactForm.reset();

    // Resets to provided model
    this.contactForm.reset({ personalData: new VehicleTripLogFullDto(), requestType: '', text: '' });
  }

  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertVehicleTripLogFull(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.alertService.showStickyMessage("Saving changes...");
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }
}
